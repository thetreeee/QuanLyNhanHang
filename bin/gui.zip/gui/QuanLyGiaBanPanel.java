package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class QuanLyGiaBanPanel extends JPanel {

    public QuanLyGiaBanPanel() {
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(20, 20));
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(20, 20, 20, 20));

        // --- PHẦN TOP: TIÊU ĐỀ VÀ NÚT CHỨC NĂNG CHÍNH ---
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(Color.WHITE);

        JLabel lblTitle = new JLabel("QUẢN LÝ GIÁ BÁN");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(50, 50, 50));
        topPanel.add(lblTitle, BorderLayout.WEST);

        // Các nút thêm, sửa, xóa góc trên bên phải
        JPanel actionButtonsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionButtonsPanel.setBackground(Color.WHITE);

        JButton btnThem = createStyledButton("+ Thêm giá", new Color(250, 210, 100), Color.BLACK);
        JButton btnSua = createStyledButton("Sửa giá", new Color(150, 200, 240), Color.BLACK);
        JButton btnXoa = createStyledButton("Xóa giá", new Color(190, 70, 80), Color.WHITE);

        actionButtonsPanel.add(btnThem);
        actionButtonsPanel.add(btnSua);
        actionButtonsPanel.add(btnXoa);
        
        topPanel.add(actionButtonsPanel, BorderLayout.EAST);

        // --- PHẦN CENTER: BỘ LỌC VÀ BẢNG DỮ LIỆU ---
        JPanel centerPanel = new JPanel(new BorderLayout(0, 20));
        centerPanel.setBackground(Color.WHITE);

        // 1. Panel Bộ lọc (Tìm kiếm, Từ ngày, Đến ngày)
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 0));
        filterPanel.setBackground(Color.WHITE);

        filterPanel.add(new JLabel("Tìm kiếm:"));
        JTextField txtTimKiem = new JTextField(15);
        filterPanel.add(txtTimKiem);

        filterPanel.add(new JLabel("Từ ngày:"));
        JTextField txtTuNgay = new JTextField("00/00/2026", 10);
        filterPanel.add(txtTuNgay);

        filterPanel.add(new JLabel("Đến ngày:"));
        JTextField txtDenNgay = new JTextField("00/00/2026", 10);
        filterPanel.add(txtDenNgay);

        JButton btnXem = createStyledButton("Xem", new Color(255, 110, 120), Color.WHITE);
        filterPanel.add(btnXem);

        centerPanel.add(filterPanel, BorderLayout.NORTH);

        // 2. Bảng dữ liệu (JTable)
        String[] columnNames = {"Tên món", "Giá bán", "Từ ngày", "Đến ngày", "Hành động"};
        Object[][] data = {
                {"Gà nướng muối ớt", "250,000", "07/07/2025", "20/12/2025", "Sửa | Xóa"},
                {"Gà nướng muối ớt", "299,000", "18/03/2026", "20/04/2026", "Sửa"},
                {"Mực nướng", "100,000", "18/03/2026", "20/04/2026", "Sửa"},
                {"Gỏi cá", "250,000", "18/03/2026", "20/04/2026", "Sửa"},
                {"Nước cam", "25,000", "18/03/2026", "20/04/2026", "Sửa"},
                {"Combo 2 người", "499,000", "18/03/2026", "20/04/2026", "Sửa"},
                {"Combo gia đình", "799,000", "18/03/2026", "20/04/2026", "Sửa"},
                {"Combo tiệc sinh nhật", "1,999,999", "07/07/2025", "20/12/2025", "Sửa | Xóa"}
        };

        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        JTable table = new JTable(model);
        table.setRowHeight(40);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        // Tùy chỉnh Tiêu đề cột (Header) để giống màu hồng nhạt trong ảnh
        JTableHeader header = table.getTableHeader();
        header.setBackground(new Color(252, 235, 235)); // Màu nền hồng nhạt
        header.setForeground(new Color(180, 50, 60));   // Màu chữ đỏ đô
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setPreferredSize(new Dimension(100, 40));
        ((DefaultTableCellRenderer) header.getDefaultRenderer()).setHorizontalAlignment(JLabel.CENTER);

        // Căn giữa dữ liệu các cột
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(240, 240, 240)));
        scrollPane.getViewport().setBackground(Color.WHITE);

        centerPanel.add(scrollPane, BorderLayout.CENTER);

        // Thêm các thành phần vào Panel chính
        add(topPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
    }

    // Hàm tiện ích để tạo nút bấm với màu sắc tùy chỉnh
    private JButton createStyledButton(String text, Color bgColor, Color fgColor) {
        JButton button = new JButton(text);
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setPreferredSize(new Dimension(100, 35));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
}