package gui;

import com.formdev.flatlaf.FlatLightLaf;
import gui.GUITaiKhoan;
import javax.swing.*;

public class GUI_Main {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new FlatLightLaf());
            
            UIManager.put("Button.arc", 15);
            UIManager.put("Component.arc", 15);
            UIManager.put("TextComponent.arc", 15);
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            new GUITaiKhoan().setVisible(true);
        });
    }
}