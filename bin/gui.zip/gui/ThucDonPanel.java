package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class ThucDonPanel extends JPanel {

    private final Color BG_COLOR = new Color(240, 242, 245);
    private final Color BLUE_ACCENT = new Color(54, 92, 245);
    private final Color TEXT_DARK = new Color(44, 56, 74);

    private JPanel productGrid;
    private List<FoodItem> allFoods = new ArrayList<>();
    private List<JButton> categoryButtons = new ArrayList<>();

    public ThucDonPanel() {
        setLayout(new BorderLayout());
        setBackground(BG_COLOR);
        setBorder(new EmptyBorder(30, 40, 30, 40));

        // --- KHỞI TẠO DỮ LIỆU MẪU ---
        initData();

        // --- TOP: SEARCH & TIME ---
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JTextField txtSearch = new JTextField(" Tìm kiếm món ăn...");
        txtSearch.setPreferredSize(new Dimension(350, 45));
        header.add(txtSearch, BorderLayout.WEST);

        JLabel lblTime = new JLabel();
        lblTime.setFont(new Font("Segoe UI", Font.BOLD, 16));
        header.add(lblTime, BorderLayout.EAST);
        
        new Timer(1000, e -> lblTime.setText(new SimpleDateFormat("EEEE, dd/MM/yyyy  HH:mm:ss").format(new Date()))).start();

        add(header, BorderLayout.NORTH);

        // --- CENTER: CATEGORY & GRID ---
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setOpaque(false);

        // 1. Thanh phân loại (Category Bar)
        JPanel categoryBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 25));
        categoryBar.setOpaque(false);
        String[] categories = {"Tất cả", "Khai vị", "Món chính", "Lẩu", "Đồ uống", "Tráng miệng"};
        
        for (String cat : categories) {
            JButton btnCat = new JButton(cat);
            btnCat.setPreferredSize(new Dimension(110, 38));
            btnCat.setFocusPainted(false);
            btnCat.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btnCat.setFont(new Font("Segoe UI", Font.BOLD, 13));
            
            // Thiết lập màu mặc định
            updateButtonStyle(btnCat, cat.equals("Tất cả"));
            
            // Sự kiện Lọc
            btnCat.addActionListener(e -> {
                filterFood(cat);
                updateCategoryButtons(btnCat);
            });
            
            categoryButtons.add(btnCat);
            categoryBar.add(btnCat);
        }
        centerPanel.add(categoryBar, BorderLayout.NORTH);

        // 2. Danh sách món ăn (Grid)
        productGrid = new JPanel(new GridLayout(0, 4, 25, 25)); 
        productGrid.setOpaque(false);

        JScrollPane scrollPane = new JScrollPane(productGrid);
        scrollPane.setBorder(null);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // Hiển thị tất cả món ăn lúc ban đầu
        filterFood("Tất cả");
    }

    private void initData() {
        allFoods.add(new FoodItem("Bò Bít Tết", "250.000đ", "icons/bobittet.png", "Món chính"));
        allFoods.add(new FoodItem("Pizza Hải Sản", "185.000đ", "icons/pizza.png", "Món chính"));
        allFoods.add(new FoodItem("Mỳ Ý", "95.000đ", "icons/pasta.png", "Món chính"));
        allFoods.add(new FoodItem("Salad Nga", "65.000đ", "icons/salad.png", "Khai vị"));
        allFoods.add(new FoodItem("Gà Rán Giòn", "45.000đ", "icons/garan.png", "Khai vị"));
        allFoods.add(new FoodItem("Nước Cam", "35.000đ", "icons/nuoccam.png", "Đồ uống"));
        allFoods.add(new FoodItem("Nước Chanh", "45.000đ", "icons/nuocchanh.png", "Đồ uống"));
        allFoods.add(new FoodItem("Tôm Hùm", "400.000đ", "icons/tomhum.png", "Món chính"));
        allFoods.add(new FoodItem("Mousse Chanh Dây", "60.000đ", "icons/BanhMousseChanhDay.jpg", "Tráng miệng"));
        allFoods.add(new FoodItem("Lẩu Gà Lá Giang", "160.000đ", "icons/LauGaLaGiang.jpg", "Lẩu"));
        allFoods.add(new FoodItem("Lẩu Hải Sản", "220.000đ", "icons/LauHaiSan.jpg", "Lẩu"));
        allFoods.add(new FoodItem("Lẩu Kim Chi", "150.000đ", "icons/LauKimChi.jpg", "Lẩu"));
        allFoods.add(new FoodItem("Lẩu Nấm", "190.000đ", "icons/LauNam.jpg", "Lẩu"));
        allFoods.add(new FoodItem("Lẩu Thái", "200.000đ", "icons/LauThai.jpg", "Lẩu"));
        allFoods.add(new FoodItem("Cơm Chiên Dương Châu", "65.000đ", "icons/ComChienDuongChau.jpg", "Khai vị"));
        allFoods.add(new FoodItem("Gỏi Bò Bóp Thấu", "45.000đ", "icons/GoiBoBopThau.jpg", "Khai vị"));
        allFoods.add(new FoodItem("Súp Cua", "50.000đ", "icons/SupCua.jpg", "Khai vị"));
    }

    // --- HÀM LỌC MÓN ĂN ---
    private void filterFood(String category) {
        productGrid.removeAll(); // Xóa hết card cũ
        
        for (FoodItem food : allFoods) {
            if (category.equals("Tất cả") || food.category.equalsIgnoreCase(category)) {
                productGrid.add(createFoodCard(food.name, food.price, food.imagePath));
            }
        }
        
        productGrid.revalidate();
        productGrid.repaint();
    }

    private void updateCategoryButtons(JButton selectedBtn) {
        for (JButton btn : categoryButtons) {
            updateButtonStyle(btn, btn == selectedBtn);
        }
    }

    private void updateButtonStyle(JButton btn, boolean isActive) {
        btn.setBackground(isActive ? BLUE_ACCENT : Color.WHITE);
        btn.setForeground(isActive ? Color.WHITE : TEXT_DARK);
    }

    private JPanel createFoodCard(String name, String price, String imgPath) {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.dispose();
            }
        };
        card.setLayout(new BorderLayout());
        card.setPreferredSize(new Dimension(220, 280));
        card.setOpaque(false);

        JLabel lblImg = new JLabel("", SwingConstants.CENTER);
        lblImg.setPreferredSize(new Dimension(220, 160));
        
        ImageIcon icon = getIconFromFile(imgPath, 140);
        if (icon != null) lblImg.setIcon(icon);
        else lblImg.setText("IMAGE");
        
        card.add(lblImg, BorderLayout.CENTER);

        JPanel info = new JPanel(new GridLayout(2, 1, 0, 5));
        info.setOpaque(false);
        info.setBorder(new EmptyBorder(10, 20, 20, 20));

        JLabel lblName = new JLabel(name);
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 16));
        
        JLabel lblPrice = new JLabel(price);
        lblPrice.setForeground(BLUE_ACCENT);
        lblPrice.setFont(new Font("Segoe UI", Font.BOLD, 15));

        info.add(lblName);
        info.add(lblPrice);
        card.add(info, BorderLayout.SOUTH);

        return card;
    }

    private ImageIcon getIconFromFile(String path, int size) {
        File f = new File(path);
        if (f.exists()) {
            Image img = new ImageIcon(path).getImage().getScaledInstance(size, -1, Image.SCALE_SMOOTH);
            return new ImageIcon(img);
        }
        return null;
    }
}