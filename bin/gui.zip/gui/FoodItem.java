package gui;

public class FoodItem {
    String name, price, imagePath, category;

    public FoodItem(String name, String price, String imagePath, String category) {
        this.name = name;
        this.price = price;
        this.imagePath = imagePath;
        this.category = category;
    }
}