package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NhanVienPanel extends JPanel {

    private final Color BG_COLOR = new Color(255, 246, 246);
    private final Color BLUE_ACCENT = new Color(54, 92, 245);
    private final Color TEXT_DARK = new Color(44, 56, 74);
    private final Color YELLOW_BTN = new Color(255, 193, 7);
    private final Color LIGHT_BLUE = new Color(173, 216, 230);

    public NhanVienPanel() {
        setLayout(new BorderLayout());
        setBackground(BG_COLOR);
        setBorder(new EmptyBorder(20, 30, 20, 30));

        
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS));
        topPanel.setOpaque(false);

        // 1. Dòng thời gian
        JLabel lblTime = new JLabel();
        lblTime.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        new Timer(1000, e -> lblTime.setText(new SimpleDateFormat("EEEE, dd/MM/yyyy - HH:mm:ss").format(new Date()))).start();
        topPanel.add(lblTime);
        topPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // 2. Dòng tiêu đề và nút chức năng
        JPanel titleActionPanel = new JPanel(new BorderLayout());
        titleActionPanel.setOpaque(false);

        JLabel lblTitle = new JLabel("QUẢN LÝ NHÂN VIÊN");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(TEXT_DARK);
        titleActionPanel.add(lblTitle, BorderLayout.WEST);

        JPanel btnActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        btnActions.setOpaque(false);

        JButton btnAdd = new JButton("+ Thêm nhân viên");
        styleHeaderButton(btnAdd, YELLOW_BTN, Color.BLACK);
        
        JButton btnEdit = new JButton("Sửa nhân viên");
        styleHeaderButton(btnEdit, LIGHT_BLUE, TEXT_DARK);

        btnActions.add(btnAdd);
        btnActions.add(btnEdit);
        titleActionPanel.add(btnActions, BorderLayout.EAST);

        topPanel.add(titleActionPanel);
        add(topPanel, BorderLayout.NORTH);

        // --- CENTER: SEARCH & TABLE AREA ---
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setOpaque(false);
        centerPanel.setBorder(new EmptyBorder(20, 0, 0, 0));

        // 3. Thanh tìm kiếm
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 10));
        searchPanel.setOpaque(false);

        JLabel lblSearch = new JLabel("Tìm kiếm:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        JTextField txtSearch = new JTextField();
        txtSearch.setPreferredSize(new Dimension(250, 35));

        JButton btnSearch = new JButton("Tìm");
        styleHeaderButton(btnSearch, new Color(255, 102, 102), Color.WHITE);
        
        JButton btnReset = new JButton("Làm mới");
        styleHeaderButton(btnReset, new Color(153, 204, 255), TEXT_DARK);

        searchPanel.add(lblSearch);
        searchPanel.add(txtSearch);
        searchPanel.add(btnSearch);
        searchPanel.add(btnReset);
        centerPanel.add(searchPanel, BorderLayout.NORTH);

        // 4. Bảng nhân viên
        String[] columnNames = {"Mã nhân viên", "Tên nhân viên", "Chức vụ", "Tổng số giờ làm", "Lương", "Trạng thái"};
        Object[][] data = {
            {"QL001", "Phan Phụng Vũ", "QUANLY", "50.02", "15,000,000", "Đang làm việc"},
            {"NV002", "Nguyễn Thị Tùng Vy", "NHANVIENTHUNGAN", "500.23", "5,000,000", "Đang làm việc"},
            {"NV003", "Trương Minh Việt", "NHANVIENPHUCVU", "230.50", "3,000,000", "Đã nghỉ"},
            {"NV004", "Bùi Minh Tuấn", "NHANVIENBEP", "465.13", "5,000,000", "Đã nghỉ"},
            {"NV005", "Trần Mạnh Trường", "NHANVIENPHUCVU", "658.32", "3,000,000", "Đã nghỉ"}
        };

        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        JTable table = new JTable(model);
        
        // Custom Table
        table.setRowHeight(45);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setSelectionBackground(new Color(235, 240, 255));
        table.setShowVerticalLines(false);
        table.setGridColor(new Color(230, 230, 230));

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(255, 235, 235)); // Màu hồng nhạt theo hình 1
        header.setPreferredSize(new Dimension(0, 40));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);
    }

    private void styleHeaderButton(JButton btn, Color bg, Color fg) {
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(130, 35));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createLineBorder(bg.darker(), 1));
    }
}