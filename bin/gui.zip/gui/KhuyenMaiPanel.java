package gui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;

public class KhuyenMaiPanel extends JPanel {

    private final Color BG_COLOR = new Color(240, 242, 245);
    private final Color BLUE_ACCENT = new Color(54, 92, 245);
    private final Color RED_BTN = new Color(220, 53, 69);
    private final Color TEXT_DARK = new Color(44, 56, 74);

    public KhuyenMaiPanel() {
        setLayout(new BorderLayout());
        setBackground(BG_COLOR);
        setBorder(new EmptyBorder(30, 40, 30, 40));

        
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.setPreferredSize(new Dimension(0, 60));

       
        JLabel lblTitle = new JLabel("Quản lý khuyến mãi");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setForeground(TEXT_DARK);
        header.add(lblTitle, BorderLayout.WEST);

        
        JPanel toolsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 0));
        toolsPanel.setOpaque(false);

       
        String[] filters = {"Lọc theo số tiền", "Lọc theo phần trăm (%)", "Tất cả chương trình"};
        JComboBox<String> cbFilter = new JComboBox<>(filters);
        cbFilter.setPreferredSize(new Dimension(220, 40));
        cbFilter.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        toolsPanel.add(cbFilter);

     
        JButton btnStop = new JButton("Ngưng áp dụng");
        btnStop.setBackground(RED_BTN);
        btnStop.setForeground(Color.WHITE);
        btnStop.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnStop.setPreferredSize(new Dimension(150, 42));
        btnStop.setFocusPainted(false);
        btnStop.setCursor(new Cursor(Cursor.HAND_CURSOR));
        toolsPanel.add(btnStop);

        
        JButton btnAdd = new JButton("+ Thêm khuyến mãi");
        btnAdd.setBackground(BLUE_ACCENT);
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnAdd.setPreferredSize(new Dimension(180, 42));
        btnAdd.setFocusPainted(false);
        btnAdd.setCursor(new Cursor(Cursor.HAND_CURSOR));
        toolsPanel.add(btnAdd);

        header.add(toolsPanel, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        
        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setOpaque(false);
        tableContainer.setBorder(new EmptyBorder(25, 0, 0, 0));

        
        String[] columnNames = {"Mã KM", "Tên chương trình", "Hình thức", "Giá trị", "Ngày bắt đầu", "Ngày kết thúc", "Trạng thái"};
        Object[][] data = {
            {"KM001", "Chào hè rực rỡ", "Phần trăm", "15%", "01/06/2026", "30/06/2026", "Đang chạy"},
            {"KM002", "Giảm giá sâu", "Số tiền", "100.000đ", "15/03/2026", "20/03/2026", "Sắp diễn ra"},
            {"KM003", "Tiệc tối ưu đãi", "Phần trăm", "10%", "01/03/2026", "05/03/2026", "Đã kết thúc"},
            {"KM004", "Happy Birthday", "Số tiền", "50.000đ", "01/01/2026", "31/12/2026", "Đang chạy"}
        };

        DefaultTableModel model = new DefaultTableModel(data, columnNames) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };

        JTable table = new JTable(model);
        
       
        table.setRowHeight(45); 
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setSelectionBackground(new Color(232, 240, 254));
        table.setSelectionForeground(Color.BLACK);
        table.setShowVerticalLines(false); 
        table.setGridColor(new Color(230, 230, 230));

       
        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableHeader.setBackground(Color.WHITE);
        tableHeader.setForeground(TEXT_DARK);
        tableHeader.setPreferredSize(new Dimension(0, 45));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(210, 210, 210), 1));
        scrollPane.getViewport().setBackground(Color.WHITE);
        
        tableContainer.add(scrollPane, BorderLayout.CENTER);
        add(tableContainer, BorderLayout.CENTER);
    }
}